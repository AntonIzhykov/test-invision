export const defaultUrl = "http://antonizhykov.front.challenge.dev.monospacelabs.com/users";
